import com.comsol.model.*;
import com.comsol.model.util.*;

/** Small, exploratory thermal-fracture benchmark; SI units throughout. */
public class BasaltCooling3D {
  public static Model run() throws Exception {
    Model m=ModelUtil.create("Model");
    m.label("Basalt cooling - 3D exploratory fracture");
    String[][] params={
      {"W","16[mm]","Width and breadth"},{"H","8[mm]","Depth"},
      {"E0","50[GPa]","Exploratory Young modulus"},{"nu0","0.25","Poisson ratio"},
      {"rho0","2900[kg/m^3]","Density"},{"k0","2[W/(m*K)]","Thermal conductivity"},
      {"cp0","900[J/(kg*K)]","Heat capacity"},{"alpha0","8e-6[1/K]","Thermal expansion"},
      {"Gc0","100[J/m^2]","Uncalibrated fracture energy"},
      {"ell","0.8[mm]","Phase-field regularization length, not crack opening"},
      {"he","ell/2","Maximum element size"},{"Thot","1200[K]","Initial stress-free temperature"},
      {"Tamb","293[K]","Ambient temperature"},{"hconv","400[W/(m^2*K)]","Strong cooling benchmark; not calibrated natural convection"},
      {"taupf","0.2[s]","Numerical viscous regularization; requires sensitivity check"},
      {"hetero","0.25","Small deterministic toughness perturbation"}
    };
    for(String[] p:params) m.param().set(p[0],p[1],p[2]);
    m.component().create("comp1",true);
    m.component("comp1").geom().create("geom1",3);
    m.component("comp1").geom("geom1").create("r1","Block");
    m.component("comp1").geom("geom1").feature("r1").set("size",new String[]{"W","W","H"});
    m.component("comp1").geom("geom1").run();
    box(m,"top",2,"-1e-8","W+1e-8","-1e-8","W+1e-8","H-1e-8","H+1e-8");
    box(m,"bottom",2,"-1e-8","W+1e-8","-1e-8","W+1e-8","-1e-8","1e-8");
    box(m,"bottomEdges",1,"-1e-8","W+1e-8","-1e-8","W+1e-8","-1e-8","1e-8");
    box(m,"pin",0,"-1e-8","1e-8","-1e-8","1e-8","-1e-8","1e-8");
    box(m,"roll",0,"W-1e-8","W+1e-8","-1e-8","1e-8","-1e-8","1e-8");
    box(m,"third",0,"-1e-8","1e-8","W-1e-8","W+1e-8","-1e-8","1e-8");
    m.component("comp1").variable().create("var1");
    m.component("comp1").variable("var1").set("Gc_local","Gc0*(1+hetero*(0.5*sin(2*pi*(x+0.37*y)/(3.7[mm]))*cos(2*pi*(y-0.21*x)/(4.3[mm]))+0.5*sin(2*pi*(x+0.63*y+0.19*z)/(2.9[mm]))))");

    m.component("comp1").material().create("mat1","Common");
    m.component("comp1").material("mat1").label("Basalt - provisional constant properties");
    m.component("comp1").material("mat1").propertyGroup("def").set("density","rho0");
    m.component("comp1").material("mat1").propertyGroup("def").set("thermalconductivity",new String[]{"k0","0","0","0","k0","0","0","0","k0"});
    m.component("comp1").material("mat1").propertyGroup("def").set("heatcapacity","cp0");
    m.component("comp1").material("mat1").propertyGroup().create("Enu","Enu","Elastic constants");
    m.component("comp1").material("mat1").propertyGroup("Enu").set("E","E0");
    m.component("comp1").material("mat1").propertyGroup("Enu").set("nu","nu0");

    m.component("comp1").physics().create("ht","HeatTransfer","geom1");
    m.component("comp1").physics("ht").prop("ShapeProperty").set("order_temperature",1);
    m.component("comp1").physics("ht").feature("init1").set("Tinit","Thot");
    m.component("comp1").physics("ht").create("hf1","HeatFluxBoundary",2);
    m.component("comp1").physics("ht").feature("hf1").selection().named("top");
    m.component("comp1").physics("ht").feature("hf1").set("HeatFluxType","ConvectiveHeatFlux");
    m.component("comp1").physics("ht").feature("hf1").set("h","hconv*(1-exp(-t/1[s]))");
    m.component("comp1").physics("ht").feature("hf1").set("Text","Tamb");
    m.component("comp1").physics("ht").create("tempBottom","TemperatureBoundary",2);
    m.component("comp1").physics("ht").feature("tempBottom").selection().named("bottom");
    m.component("comp1").physics("ht").feature("tempBottom").set("T0","Thot");

    m.component("comp1").physics().create("solid","SolidMechanics","geom1");
    m.component("comp1").physics("solid").prop("ShapeProperty").set("order_displacement",1);

    m.component("comp1").physics("solid").prop("StructuralTransientBehavior").set("StructuralTransientBehavior","Quasistatic");
    m.component("comp1").physics("solid").create("fix1","Fixed",0);
    m.component("comp1").physics("solid").feature("fix1").selection().named("pin");
    m.component("comp1").physics("solid").create("disp1","Displacement0",0);
    m.component("comp1").physics("solid").feature("disp1").selection().named("roll");
    m.component("comp1").physics("solid").feature("disp1").set("Direction",new int[]{0,1,1});
    m.component("comp1").physics("solid").create("disp2","Displacement0",0);
    m.component("comp1").physics("solid").feature("disp2").selection().named("third");
    m.component("comp1").physics("solid").feature("disp2").set("Direction",new int[]{0,0,1});
    m.component("comp1").physics("solid").create("supportBottom","Displacement2",2);
    m.component("comp1").physics("solid").feature("supportBottom").selection().named("bottom");
    m.component("comp1").physics("solid").feature("supportBottom").set("Direction",new int[]{0,0,1});
    m.component("comp1").physics("solid").feature("lemm1").create("te1","ThermalExpansion",3);
    var te=m.component("comp1").physics("solid").feature("lemm1").feature("te1");
    te.set("T","T");
    te.set("Tref","Thot");
    te.set("alpha_mat","userdef");
    te.set("alpha",new String[]{"alpha0","0","0","0","alpha0","0","0","0","alpha0"});

    m.component("comp1").physics().create("pfs","PhaseFieldSolids","geom1");
    m.component("comp1").physics("pfs").feature("pfsm1").set("phaseFieldModel","AT1");
    m.component("comp1").physics("pfs").feature("pfsm1").set("lint","ell");
    m.component("comp1").physics("pfs").feature("pfsm1").set("tau","taupf");
    m.component("comp1").multiphysics().create("pfdmg1","PhaseFieldDamage",3);
    m.component("comp1").multiphysics("pfdmg1").selection().all();
    m.component("comp1").multiphysics("pfdmg1").set("Solid_physics","solid");
    m.component("comp1").multiphysics("pfdmg1").set("PhaseFieldSolids_physics","pfs");
    m.component("comp1").multiphysics("pfdmg1").set("ParentMaterialModel","lemm1");
    m.component("comp1").multiphysics("pfdmg1").set("ParentPhaseFieldModel","pfsm1");
    m.component("comp1").multiphysics("pfdmg1").set("Gc_mat","userdef");
    m.component("comp1").multiphysics("pfdmg1").set("Gc","Gc_local");
    m.component("comp1").multiphysics("pfdmg1").set("strainEnergySplit","volDev");

    m.component("comp1").mesh().create("mesh1");
    m.component("comp1").mesh("mesh1").create("map1","Map");
    m.component("comp1").mesh("mesh1").feature("map1").selection().named("bottom");
    m.component("comp1").mesh("mesh1").feature("map1").create("dis1","Distribution");
    m.component("comp1").mesh("mesh1").feature("map1").feature("dis1").selection().named("bottomEdges");
    m.component("comp1").mesh("mesh1").feature("map1").feature("dis1").set("numelem",32);
    m.component("comp1").mesh("mesh1").feature("map1").feature("dis1").set("equidistant",true);
    m.component("comp1").mesh("mesh1").create("swe1","Sweep");
    m.component("comp1").mesh("mesh1").feature("swe1").selection("sourceface").named("bottom");
    m.component("comp1").mesh("mesh1").feature("swe1").selection("targetface").named("top");
    m.component("comp1").mesh("mesh1").feature("swe1").create("dis1","Distribution");
    m.component("comp1").mesh("mesh1").feature("swe1").feature("dis1").set("numelem",16);
    m.component("comp1").mesh("mesh1").feature("size").set("custom",true);
    m.component("comp1").mesh("mesh1").feature("size").set("hmax","he");
    m.component("comp1").mesh("mesh1").feature("size").set("hmin","he/2");
    m.component("comp1").mesh("mesh1").run();
    m.study().create("std1");
    m.study("std1").create("time","Transient");
    m.study("std1").feature("time").set("tlist","range(0,1,20) range(25,5,120)");
    m.study("std1").feature("time").set("rtol","0.005");
    m.study("std1").createAutoSequences("all");
    m.sol("sol1").feature("t1").feature("se1").set("maxsegiter",30);
    m.sol("sol1").feature("t1").feature("se1").feature("ss3").set("maxsubiter",25);
    m.save("basalt_3d_setup.mph");
    m.save("Basalt3DSetupExport.java","java");
    System.out.println("BASALT3D_SETUP_COMPLETE");
    m.sol("sol1").runAll();
    m.save("basalt_3d_solved.mph");
    System.out.println("BASALT3D_SOLVE_COMPLETE");
    return m;
  }
  static void box(Model m,String tag,int dim,String xmin,String xmax,String ymin,String ymax,String zmin,String zmax) {
    m.component("comp1").selection().create(tag,"Box");
    m.component("comp1").selection(tag).set("entitydim",dim);
    m.component("comp1").selection(tag).set("xmin",xmin);
    m.component("comp1").selection(tag).set("xmax",xmax);
    m.component("comp1").selection(tag).set("ymin",ymin);
    m.component("comp1").selection(tag).set("ymax",ymax);
    m.component("comp1").selection(tag).set("zmin",zmin);
    m.component("comp1").selection(tag).set("zmax",zmax);
    m.component("comp1").selection(tag).set("condition","inside");
  }
  public static void main(String[] args) throws Exception {run();}
}





