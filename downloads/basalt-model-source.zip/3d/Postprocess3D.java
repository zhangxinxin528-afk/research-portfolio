import com.comsol.model.*;
import com.comsol.model.util.*;

/** Postprocess the computed 3D fields; no prescribed crack geometry. */
public class Postprocess3D {
  public static Model run() throws Exception {
    Model m=ModelUtil.load("Model","basalt_3d_solved.mph");
    m.modelPath("D:/国外学习（作业，课程，视频）/Rock_built/model_3d");
    m.result().create("pgTemp3D","PlotGroup3D");
    m.result("pgTemp3D").label("3D temperature (K)");
    m.result("pgTemp3D").set("data","dset1");
    m.result("pgTemp3D").create("surf1","Surface");
    m.result("pgTemp3D").feature("surf1").set("expr","T");
    m.result("pgTemp3D").feature("surf1").set("colortable","ThermalLight");
    m.result().create("pgPhase3D","PlotGroup3D");
    m.result("pgPhase3D").label("3D crack phase field on exterior");
    m.result("pgPhase3D").set("data","dset1");
    m.result("pgPhase3D").create("surf1","Surface");
    m.result("pgPhase3D").feature("surf1").set("expr","phi");
    m.result("pgPhase3D").feature("surf1").set("colortable","ThermalLight");
    m.result("pgPhase3D").feature("surf1").set("rangecoloractive",true);
    m.result("pgPhase3D").feature("surf1").set("rangecolormin",0);
    m.result("pgPhase3D").feature("surf1").set("rangecolormax",1);
    m.result().create("pgCracks3D","PlotGroup3D");
    m.result("pgCracks3D").label("Internal crack surfaces: phi = 0.8");
    m.result("pgCracks3D").set("data","dset1");
    m.result("pgCracks3D").create("iso1","Isosurface");
    m.result("pgCracks3D").feature("iso1").set("expr","phi");
    m.result("pgCracks3D").feature("iso1").set("levelmethod","levels");
    m.result("pgCracks3D").feature("iso1").set("levels","0.8");
    m.result("pgCracks3D").feature("iso1").set("colortable","ThermalLight");
    String[] fields={"phi","T"};
    String[] names={"phase_3d","temperature_3d"};
    for(int i=0;i<fields.length;i++) {
      String tag="data3d"+i;
      m.result().export().create(tag,"Data");
      m.result().export(tag).set("data","dset1");
      m.result().export(tag).set("expr",new String[]{fields[i]});
      m.result().export(tag).set("location","regulargrid");
      m.result().export(tag).set("regulargridx3","49");
      m.result().export(tag).set("regulargridy3","49");
      m.result().export(tag).set("regulargridz3","25");
      m.result().export(tag).set("header","on");
      m.result().export(tag).set("separator",",");
      m.result().export(tag).set("filename",m.modelPath()+"/"+names[i]+".csv");
      m.result().export(tag).run();
      System.out.println("EXPORTED "+names[i]);
    }
    m.result().export().create("anim3d","Animation");
    m.result().export("anim3d").set("plotgroup","pgCracks3D");
    m.result().export("anim3d").set("target","player");
    m.save("basalt_3d.mph");
    System.out.println("POSTPROCESS3D_COMPLETE");
    return m;
  }
  public static void main(String[] args) throws Exception {run();}
}
