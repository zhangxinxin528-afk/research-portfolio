import com.comsol.model.*;
import com.comsol.model.util.*;

/** Small, exploratory thermal-fracture benchmark; SI units throughout. */
public class BasaltCooling {
  public static Model run() throws Exception {
    Model m=ModelUtil.create("Model");
    m.label("Basalt cooling - 2D exploratory fracture");
    String[][] params={
      {"W","32[mm]","Width"},{"H","16[mm]","Depth"},
      {"E0","50[GPa]","Exploratory Young modulus"},{"nu0","0.25","Poisson ratio"},
      {"rho0","2900[kg/m^3]","Density"},{"k0","2[W/(m*K)]","Thermal conductivity"},
      {"cp0","900[J/(kg*K)]","Heat capacity"},{"alpha0","8e-6[1/K]","Thermal expansion"},
      {"Gc0","100[J/m^2]","Uncalibrated fracture energy"},
      {"ell","0.8[mm]","Phase-field regularization length, not crack opening"},
      {"he","ell/3","Maximum element size"},{"Thot","1200[K]","Initial stress-free temperature"},
      {"Tamb","293[K]","Ambient temperature"},{"hconv","1000[W/(m^2*K)]","Strong cooling benchmark; not calibrated natural convection"},
      {"taupf","0.05[s]","Numerical viscous regularization; requires sensitivity check"},
      {"hetero","0.05","Small deterministic toughness perturbation"}
    };
    for(String[] p:params) m.param().set(p[0],p[1],p[2]);
    m.component().create("comp1",true);
    m.component("comp1").geom().create("geom1",2);
    m.component("comp1").geom("geom1").create("r1","Rectangle");
    m.component("comp1").geom("geom1").feature("r1").set("size",new String[]{"W","H"});
    m.component("comp1").geom("geom1").run();
    box(m,"top",1,"-1e-8","W+1e-8","H-1e-8","H+1e-8");
    box(m,"pin",0,"-1e-8","1e-8","-1e-8","1e-8");
    box(m,"roll",0,"W-1e-8","W+1e-8","-1e-8","1e-8");
    m.component("comp1").variable().create("var1");
    m.component("comp1").variable("var1").set("Gc_local","Gc0*(1+hetero*sin(2*pi*x/(3.7[mm]))*cos(2*pi*y/(4.3[mm])))");

    m.component("comp1").material().create("mat1","Common");
    m.component("comp1").material("mat1").label("Basalt - provisional constant properties");
    m.component("comp1").material("mat1").propertyGroup("def").set("density","rho0");
    m.component("comp1").material("mat1").propertyGroup("def").set("thermalconductivity",new String[]{"k0","0","0","0","k0","0","0","0","k0"});
    m.component("comp1").material("mat1").propertyGroup("def").set("heatcapacity","cp0");
    m.component("comp1").material("mat1").propertyGroup().create("Enu","Enu","Elastic constants");
    m.component("comp1").material("mat1").propertyGroup("Enu").set("E","E0");
    m.component("comp1").material("mat1").propertyGroup("Enu").set("nu","nu0");

    m.component("comp1").physics().create("ht","HeatTransfer","geom1");
    m.component("comp1").physics("ht").prop("ShapeProperty").set("order_temperature",1);
    m.component("comp1").physics("ht").feature("init1").set("Tinit","Thot");
    m.component("comp1").physics("ht").create("hf1","HeatFluxBoundary",1);
    m.component("comp1").physics("ht").feature("hf1").selection().named("top");
    m.component("comp1").physics("ht").feature("hf1").set("HeatFluxType","ConvectiveHeatFlux");
    m.component("comp1").physics("ht").feature("hf1").set("h","hconv*(1-exp(-t/1[s]))");
    m.component("comp1").physics("ht").feature("hf1").set("Text","Tamb");

    m.component("comp1").physics().create("solid","SolidMechanics","geom1");
    m.component("comp1").physics("solid").prop("ShapeProperty").set("order_displacement",1);
    m.component("comp1").physics("solid").prop("Type2D").set("Type2D","PlaneStress");
    m.component("comp1").physics("solid").prop("StructuralTransientBehavior").set("StructuralTransientBehavior","Quasistatic");
    m.component("comp1").physics("solid").create("fix1","Fixed",0);
    m.component("comp1").physics("solid").feature("fix1").selection().named("pin");
    m.component("comp1").physics("solid").create("disp1","Displacement0",0);
    m.component("comp1").physics("solid").feature("disp1").selection().named("roll");
    m.component("comp1").physics("solid").feature("disp1").set("Direction",new int[]{0,1,0});
    m.component("comp1").physics("solid").feature("lemm1").create("te1","ThermalExpansion",2);
    var te=m.component("comp1").physics("solid").feature("lemm1").feature("te1");
    te.set("T","T");
    te.set("Tref","Thot");
    te.set("alpha_mat","userdef");
    te.set("alpha",new String[]{"alpha0","0","0","0","alpha0","0","0","0","alpha0"});

    m.component("comp1").physics().create("pfs","PhaseFieldSolids","geom1");
    m.component("comp1").physics("pfs").feature("pfsm1").set("phaseFieldModel","AT1");
    m.component("comp1").physics("pfs").feature("pfsm1").set("lint","ell");
    m.component("comp1").physics("pfs").feature("pfsm1").set("tau","taupf");
    m.component("comp1").multiphysics().create("pfdmg1","PhaseFieldDamage",2);
    m.component("comp1").multiphysics("pfdmg1").selection().all();
    m.component("comp1").multiphysics("pfdmg1").set("Solid_physics","solid");
    m.component("comp1").multiphysics("pfdmg1").set("PhaseFieldSolids_physics","pfs");
    m.component("comp1").multiphysics("pfdmg1").set("ParentMaterialModel","lemm1");
    m.component("comp1").multiphysics("pfdmg1").set("ParentPhaseFieldModel","pfsm1");
    m.component("comp1").multiphysics("pfdmg1").set("Gc_mat","userdef");
    m.component("comp1").multiphysics("pfdmg1").set("Gc","Gc_local");
    m.component("comp1").multiphysics("pfdmg1").set("strainEnergySplit","stress");

    m.component("comp1").mesh().create("mesh1");
    m.component("comp1").mesh("mesh1").create("tri1","FreeTri");
    m.component("comp1").mesh("mesh1").feature("size").set("custom",true);
    m.component("comp1").mesh("mesh1").feature("size").set("hmax","he");
    m.component("comp1").mesh("mesh1").feature("size").set("hmin","he/2");
    m.component("comp1").mesh("mesh1").run();
    m.study().create("std1");
    m.study("std1").create("time","Transient");
    m.study("std1").feature("time").set("tlist","range(0,0.5,10) range(12,2,120)");
    m.study("std1").feature("time").set("rtol","0.005");
    m.study("std1").createAutoSequences("all");
    m.sol("sol1").feature("t1").feature("se1").set("maxsegiter",30);
    m.sol("sol1").feature("t1").feature("se1").feature("ss3").set("maxsubiter",25);
    m.save("basalt_2d_setup.mph");
    m.save("BasaltSetupExport.java","java");
    System.out.println("BASALT_SETUP_COMPLETE");
    m.sol("sol1").runAll();
    m.save("basalt_2d_solved.mph");
    System.out.println("BASALT_SOLVE_COMPLETE");
    return m;
  }
  static void box(Model m,String tag,int dim,String xmin,String xmax,String ymin,String ymax) {
    m.component("comp1").selection().create(tag,"Box");
    m.component("comp1").selection(tag).set("entitydim",dim);
    m.component("comp1").selection(tag).set("xmin",xmin);
    m.component("comp1").selection(tag).set("xmax",xmax);
    m.component("comp1").selection(tag).set("ymin",ymin);
    m.component("comp1").selection(tag).set("ymax",ymax);
    m.component("comp1").selection(tag).set("condition","inside");
  }
  public static void main(String[] args) throws Exception {run();}
}
