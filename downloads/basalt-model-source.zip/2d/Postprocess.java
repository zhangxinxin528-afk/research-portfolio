import com.comsol.model.*;
import com.comsol.model.util.*;

public class Postprocess {
  public static Model run() throws Exception {
    return process(ModelUtil.load("Model","basalt_2d_solved.mph"));
  }
  public static Model process(Model m) throws Exception {
    m.modelPath("D:/国外学习（作业，课程，视频）/Rock_built");
    // sdxx, sdyy, sdxy and sdzz include damage. solid.sp1 is the undegraded stress.
    String actualStress="max(solid.sdzz,(solid.sdxx+solid.sdyy)/2+sqrt(((solid.sdxx-solid.sdyy)/2)^2+solid.sdxy^2))";
    plot(m,"pgTemp","Temperature (K)","T","ThermalLight");
    plot(m,"pgPhase","Crack phase field (0 intact, 1 fractured)","phi","ThermalLight");
    m.result("pgPhase").feature("surf1").set("rangecoloractive",true);
    m.result("pgPhase").feature("surf1").set("rangecolormin",0);
    m.result("pgPhase").feature("surf1").set("rangecolormax",1);
    plot(m,"pgStress","Maximum principal stress including damage (MPa)","("+actualStress+")/1[MPa]","RainbowLight");
    String[] fields={"phi","T",actualStress};
    String[] names={"phase","temperature","stress"};
    for(int i=0;i<3;i++) {
      String tag="data"+i;
      m.result().export().create(tag,"Data");
      m.result().export(tag).set("data","dset1");
      m.result().export(tag).set("expr",new String[]{fields[i]});
      m.result().export(tag).set("location","regulargrid");
      m.result().export(tag).set("regulargridx2","161");
      m.result().export(tag).set("regulargridy2","81");
      m.result().export(tag).set("header","on");
      m.result().export(tag).set("separator",",");
      m.result().export(tag).set("filename",m.modelPath()+"/"+names[i]+".csv");
      m.result().export(tag).run();
      System.out.println("EXPORTED "+names[i]);
    }
    m.result().export().create("anim1","Animation");
    m.result().export("anim1").set("plotgroup","pgPhase");
    m.result().export("anim1").set("target","player");
    m.save("basalt_2d.mph");
    System.out.println("POSTPROCESS_COMPLETE");
    return m;
  }
  static void plot(Model m,String tag,String label,String expr,String color) {
    m.result().create(tag,"PlotGroup2D");
    m.result(tag).label(label);
    m.result(tag).set("data","dset1");
    m.result(tag).create("surf1","Surface");
    m.result(tag).feature("surf1").set("expr",expr);
    m.result(tag).feature("surf1").set("colortable",color);
  }
  public static void main(String[] args) throws Exception {run();}
}
