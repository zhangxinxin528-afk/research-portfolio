Cooling-fracture research prototype

COMSOL 6.4 Java model sources and original documentation.
These are model-building sources, not solved MPH files. The Java sources may retain original local paths; adapt output locations before running.
Compile and run using the COMSOL Java API and a compatible licensed installation. Read the model documentation first. Rebuilding solves the model and can overwrite outputs.

The 3D example is the continuous 0–120 s, 16 x 16 x 8 mm case. It produces approximately orthogonal cracks, not a validated natural basalt column population. No 2–100 s pilot continuation is included. Material parameters and mesh convergence remain exploratory.
