"""Reproduce the native R2 A/B pulse with NumPy/SciPy, without COMSOL or project paths."""
from pathlib import Path
import os, sys, json, hashlib, argparse, time
os.environ['BM03_LINEAR_SOLVER']='scipy'
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
HERE=Path(__file__).resolve().parent
import numpy as np
import scipy
import bm03_ec_model as engine

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=HERE/'results');args=parser.parse_args()
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    if (out/'validation.json').exists():raise SystemExit('Choose a new --output directory to preserve an earlier run.')
    src=read(HERE/'source_provenance.json')
    assert hashlib.sha256((HERE/'bm03_ec_model.py').read_bytes()).hexdigest()==src['engine_sha256']
    for name,digest in src['input_sha256'].items():assert hashlib.sha256((HERE/'input'/name).read_bytes()).hexdigest()==digest
    engine.EC=HERE/'input';design=read(engine.EC/'design.json');expected=read(engine.EC/'expected.json');report=[];start=time.perf_counter()
    for side,case in [('A','concentrated'),('B','dispersed')]:
        model=engine.Model(case,1);model.I=design['projected_I_A']
        state,records=model.run(dt=.5,duration=20.,scheme='CN')
        theta=state[model.np:];j=model.reaction(state[:model.np],theta)[0];ref=np.load(HERE/'input'/f'expected_{side}.npz');target=next(r for r in expected if r['side']==side)
        theta_error=float(np.max(abs(theta-ref['theta'])));j_error=float(np.linalg.norm(j-ref['j'])/np.linalg.norm(ref['j']));V_error=abs(records[-1]['terminal_relative_U0_V']-target['V']);W_error=abs(theta.var()/target['W']-1)
        current=max(r['current_relative_error'] for r in records);inventory=max(r['inventory_relative_error'] for r in records)
        window=max(max(abs(r[k]-.65) for k in ['theta_min','theta_max','surface_min','surface_max']) for r in records)
        valid=theta_error<1e-7 and j_error<1e-5 and V_error<1e-6 and W_error<1e-5 and current<1e-6 and inventory<1e-6 and window<=.05
        row=dict(side=side,valid=bool(valid),V=records[-1]['terminal_relative_U0_V'],W_all=float(theta.var()),theta_max_error=theta_error,j_relative_L2=j_error,V_absolute_error=V_error,W_relative_error=W_error,current_relative=current,inventory_relative=inventory,window=window)
        report.append(row);np.savez_compressed(out/f'{side}_fields.npz',theta=theta,j=j,cam_coords=model.cam)
        (out/f'{side}_records.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
        assert valid,row
    delta=report[0]['W_all']-report[1]['W_all'];target=expected[0]['W']-expected[1]['W'];assert abs(delta-target)<1e-10
    result=dict(valid=True,scope='Reproduction of two existing native-grid cases, not new scientific validation or fine-grid reproduction.',python=sys.version,numpy=np.__version__,scipy=scipy.__version__,solver='SciPy SuperLU, one requested BLAS thread',seconds=time.perf_counter()-start,cases=report,delta_W=delta,archived_delta_W=target,delta_absolute_error=abs(delta-target),thresholds=dict(theta_max_abs=1e-7,j_relative_L2=1e-5,V_abs=1e-6,W_relative=1e-5,current_inventory_relative=1e-6,theta_window=.05,delta_W_abs=1e-10))
    (out/'validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
