"""Portable imports and unchanged geometry functions from the project."""
from pathlib import Path
import os,json
import numpy as np
from scipy import ndimage,sparse
from scipy.sparse import linalg as sla
EC=Path(__file__).resolve().parent/"input"

def interfaces(v):
    ca=[];se=[];axes=[];cent=[]
    for d in range(3):
        a=[slice(None)]*3;b=a.copy();a[d]=slice(None,-1);b[d]=slice(1,None)
        aa=v[tuple(a)];bb=v[tuple(b)]
        for p,q in [(1,2),(2,1)]:
            coords=np.argwhere((aa==p)&(bb==q));other=coords.copy();other[:,d]+=1
            ca.extend(coords if p==1 else other);se.extend(other if p==1 else coords)
            c=coords.astype(float)+.5;c[:,d]+=.5;cent.extend(c);axes.extend([d]*len(c))
    return np.array(ca,int).reshape(-1,3),np.array(se,int).reshape(-1,3),np.array(axes,int),np.array(cent,float).reshape(-1,3)

def geometry_metrics(v):
    labs=[];reachable=[];cc=[]
    for phase,side in [(1,-1),(2,0)]:
        lab,n=ndimage.label(v==phase);ids=np.unique(lab[side]);ids=ids[ids>0]
        labs.append(lab);reachable.append(np.isin(lab,ids));cc.append(np.bincount(lab.ravel()))
    ca,se,axes,c=interfaces(v);eligible=reachable[0][tuple(ca.T)]&reachable[1][tuple(se.T)]
    ids=labs[0][tuple(ca[eligible].T)]
    regions=[]
    for k in np.unique(ids):
        regions.append(dict(id=int(k),voxels=int(cc[0][k]),eligible_faces=int((ids==k).sum())))
    meaningful=[r for r in regions if r['voxels']>=max(16,.01*(v==1).sum()) and r['eligible_faces']>=8]
    return dict(shape=list(v.shape),phase_voxels=np.bincount(v.ravel(),minlength=3).tolist(),joint_faces=int(eligible.sum()),cam_supply_regions=regions,meaningful_regions=len(meaningful),cam_reachable_fraction=float(reachable[0].sum()/max(1,(v==1).sum())),ise_reachable_fraction=float(reachable[1].sum()/max(1,(v==2).sum()))),eligible,labs
