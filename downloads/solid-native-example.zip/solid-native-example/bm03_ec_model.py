"""Three-dimensional cell-centred finite volumes, nonlinear BV and CAM diffusion.

All native voxel volumes and CAM/ISE face areas are retained. Uniform refinement
subdivides the SAME labelled geometry, rather than resegmenting it. Both surface
potential and surface concentration include the half-cell flux correction.
"""
from bm03_ec_geometry import *
import time
from scipy.sparse.csgraph import connected_components
if os.environ.get('BM03_LINEAR_SOLVER','pardiso')=='pardiso':
    from bm03_parallel_solver import Factor
else:Factor=lambda A:sla.splu(A.tocsc())

DEFAULT=dict(kappa=.17,sigma=.1,D=1e-15,j0=1.,rho=4700.,theta0=.65,U0=3.85,slope=-.8,T=298.15,
             F=96485.33212,R=8.31446261815324,M=.00694+.83*.0586934+.11*.058933194+.06*.054938044+2*.015999,
             specific_current_A_kg=200.,duration=20.)

def laplacian(n,a,b,g):
    g=np.broadcast_to(g,len(a));return sparse.coo_matrix((np.r_[g,g,-g,-g],(np.r_[a,b,a,b],np.r_[a,b,b,a])),shape=(n,n)).tocsr()

class Model:
    def __init__(self,case='baseline',refine=1,parameters=None):
        self.par=p=DEFAULT.copy();p.update(parameters or {});p['cmax']=p['rho']/p['M'];self.Vt=p['R']*p['T']/p['F']
        f=np.load(EC/'geometry.npz');self.base=f['labels'];self.r=refine;self.h=1e-7/refine
        v=self.base
        for axis in range(3):v=np.repeat(v,refine,axis=axis)
        self.labels=v;self.cam=np.argwhere(v==1);self.ise=np.argwhere(v==2);self.coords=np.vstack([self.cam,self.ise]);self.nc=len(self.cam);self.np=len(self.coords)+1
        mapping=np.full(v.shape,-1,np.int32);mapping[tuple(self.coords.T)]=np.arange(len(self.coords));self.mapping=mapping
        ea=[];eb=[];eg=[];diffa=[];diffb=[]
        for d in range(3):
            a=[slice(None)]*3;b=a.copy();a[d]=slice(None,-1);b[d]=slice(1,None)
            aa=v[tuple(a)];bb=v[tuple(b)];ma=mapping[tuple(a)];mb=mapping[tuple(b)]
            for phase,cond in [(1,p['sigma']),(2,p['kappa'])]:
                ok=(aa==phase)&(bb==phase);ai=ma[ok];bi=mb[ok];ea.extend(ai);eb.extend(bi);eg.extend([cond*self.h]*len(ai))
                if phase==1:diffa.extend(ai);diffb.extend(bi)
        self.supply_cam=mapping[-1][v[-1]==1];self.supply_ise=mapping[0][v[0]==2]
        ea.extend(self.supply_cam);eb.extend([self.np-1]*len(self.supply_cam));eg.extend([2*p['sigma']*self.h]*len(self.supply_cam))
        self.ea=np.array(ea,int);self.eb=np.array(eb,int);self.eg=np.array(eg,float)
        L=laplacian(self.np,self.ea,self.eb,self.eg)
        self.ground=np.zeros(self.np);self.ground[self.supply_ise]=2*p['kappa']*self.h
        L+=sparse.diags(self.ground)
        self.Kdiff=laplacian(self.nc,np.array(diffa,int),np.array(diffb,int),1.)
        ca,se,axes,cent=interfaces(v);self.ca=mapping[tuple(ca.T)];self.se=mapping[tuple(se.T)];self.cent=cent*self.h;self.axes=axes;self.nf=len(ca)
        # Recover the parent ORIGINAL face from its two adjacent phase voxels.
        parent={(tuple(a),tuple(b)):k for k,(a,b) in enumerate(zip(f['cam_coords'],f['ise_coords']))}
        self.parent=np.array([parent[(tuple(a//refine),tuple(b//refine))] for a,b in zip(ca,se)])
        self.loss=f['loss_masks'][['baseline','concentrated','dispersed'].index(case)][self.parent]
        self.eligible=f['eligible'][self.parent];self.case=case
        self.B=sparse.coo_matrix((np.r_[np.ones(self.nf),-np.ones(self.nf)],(np.r_[self.ca,self.se],np.r_[np.arange(self.nf),np.arange(self.nf)])),shape=(self.np,self.nf)).tocsr()
        self.C=sparse.coo_matrix((np.ones(self.nf),(self.ca,np.arange(self.nf))),shape=(self.nc,self.nf)).tocsr()
        # A disconnected combined two-phase component has an arbitrary gauge.
        # This does not create transport; its gauge reaction is checked as zero.
        topology=L+self.B[:,~self.loss]@self.B[:,~self.loss].T
        _,cl=connected_components(topology,directed=False);anchored=np.unique(cl[self.supply_ise]);self.gauge=[]
        for label in np.setdiff1d(np.unique(cl),anchored):self.gauge.append(int(np.flatnonzero(cl==label)[0]))
        gauge=np.zeros(self.np);gauge[self.gauge]=p['kappa']*self.h;self.gauge_g=gauge;self.L=(L+sparse.diags(gauge)).tocsr()
        self.Vcam=self.nc*self.h**3;self.mass=p['rho']*self.Vcam;self.I=DEFAULT['rho']*(self.base==1).sum()*1e-21*p['specific_current_A_kg']
        self.inventory=p['F']*p['cmax']*self.Vcam;self.region=f['cam_components'][tuple((self.cam//refine).T)]
        self.surface_factor=self.h/(2*p['F']*p['cmax']*p['D']);self.halfR=self.h/(2*p['sigma'])+self.h/(2*p['kappa'])
        self.time_weight=1.;self.explicit_rate=0.

    def reaction(self,phi,theta):
        p=self.par;tc=theta[self.ca];eta=self.Vt*(phi[self.ca]-phi[self.se]);s=self.surface_factor
        j=np.zeros(self.nf);lo=(.00001-tc)/s;hi=(.99999-tc)/s;on=~self.loss
        for _ in range(45):
            ts=tc+s*j;root=np.sqrt(ts*(1-ts)/(p['theta0']*(1-p['theta0'])));i0=p['j0']*root
            logd=(1-2*ts)/(2*ts*(1-ts));q=j/(2*i0);inv=1/np.sqrt(1+q*q)
            fun=2*self.Vt*np.arcsinh(q)+j*self.halfR-p['slope']*(ts-p['theta0'])+eta
            ft=-2*self.Vt*inv*q*logd-p['slope']
            fj=self.Vt*inv/i0+ft*s+self.halfR
            update=np.where(on,fun/fj,0.);new=np.clip(j-update,lo+.000001/s,hi-.000001/s)
            j=np.where(on,new,0.)
            if np.max(abs(fun[on]))<1e-11:break
        else:raise RuntimeError('Face BV root did not converge')
        # Derivatives w.r.t cell-centre potential difference and concentration.
        return j,np.where(on,self.Vt/fj,0.),np.where(on,ft/fj,0.),tc+s*j

    def residual_jac(self,x,old=None,dt=None,jac=True):
        phi=x[:self.np];theta=x[self.np:] if old is not None else self.theta_fixed
        j,a,b,ts=self.reaction(phi,theta)
        # Compute flux differences BEFORE summing. L@phi cancels large common
        # electrode potentials in highly conducting cases, losing the small
        # reaction current which is needed by the integrated stopping rule.
        flux=self.eg*(phi[self.ea]-phi[self.eb])
        div=np.bincount(self.ea,weights=flux,minlength=self.np)-np.bincount(self.eb,weights=flux,minlength=self.np)+(self.ground+self.gauge_g)*phi
        rp=self.Vt*div-self.h**2*(self.B@j);rp[-1]+=self.I;rp/=self.I
        Jp=None
        if jac:Jp=(self.Vt*self.L+self.h**2*(self.B@sparse.diags(a)@self.B.T))/self.I
        if old is None:return rp,Jp,j,ts
        wd=dt*self.time_weight;rate=wd/(self.par['F']*self.par['cmax']*self.h);scale=self.I*dt/self.inventory
        rc=(theta-old+wd*self.par['D']/self.h**2*(self.Kdiff@(theta-self.par['theta0']))-rate*(self.C@j)+dt*(1-self.time_weight)*self.explicit_rate)/scale
        J=None
        if jac:
            Jpc=self.h**2*(self.B@sparse.diags(b)@self.C.T)/self.I
            Jcp=rate*(self.C@sparse.diags(a)@self.B.T)/scale
            Jcc=(sparse.eye(self.nc)+wd*self.par['D']/self.h**2*self.Kdiff+rate*(self.C@sparse.diags(b)@self.C.T))/scale
            J=sparse.bmat([[Jp,Jpc],[Jcp,Jcc]],format='csc')
        return np.r_[rp,rc],J,j,ts

    def newton(self,x,old=None,dt=None,factor=None):
        history=[]
        for it in range(30):
            residual,J,j,ts=self.residual_jac(x,old,dt,jac=factor is None);norm=np.max(abs(residual));history.append(float(norm))
            current_error=max(abs(j.sum()*self.h**2/self.I-1),abs(-self.Vt*np.dot(self.ground,x[:self.np])/self.I-1))
            if old is None or it>=6:print('NEWTON',('initial' if old is None else 'time'),it,'res',norm,'current',current_error,'refactor',factor is None,flush=True)
            if norm<2e-8 and current_error<1e-8:return x,factor,history
            merit=max(norm/2e-8,current_error/1e-8)
            if factor is None:factor=Factor(J)
            dx=factor.solve(-residual);alpha=1.
            for _ in range(15):
                trial=x+alpha*dx
                if old is not None and (trial[self.np:].min()<.05 or trial[self.np:].max()>.95):alpha*=.5;continue
                rr,_,trial_j,_=self.residual_jac(trial,old,dt,False)
                trial_current=max(abs(trial_j.sum()*self.h**2/self.I-1),abs(-self.Vt*np.dot(self.ground,trial[:self.np])/self.I-1))
                # The line search must monitor the SAME local and integrated
                # criteria as the stopping rule. Otherwise a globally better
                # step can be rejected by roundoff in an oversolved local row.
                if max(np.max(abs(rr))/2e-8,trial_current/1e-8)<merit:break
                alpha*=.5
            else:
                if it>0:factor=None;continue
                raise RuntimeError('Newton line search failed')
            x=trial
            if it>=5 and (it%6==5 or history[-1]>.8*history[-2]):factor=None
        raise RuntimeError('Newton failed: '+str(history))

    def metrics(self,x,t):
        p=self.par;phi=x[:self.np];theta=x[self.np:];j,_,_,ts=self.reaction(phi,theta);A=self.h**2
        Icam=2*p['sigma']*self.h*self.Vt*np.sum(phi[self.supply_cam]-phi[-1]);Iion=-self.Vt*np.dot(self.ground,phi)
        charge=float(self.inventory*np.mean(theta-p['theta0']));net=float(np.sum(j)*A)
        eligible_j=j[self.eligible];regions=[]
        for r in np.unique(self.region):
            inds=self.region==r;faces=inds[self.ca];regions.append(dict(region=int(r),volume_m3=float(inds.sum()*self.h**3),theta_mean=float(theta[inds].mean()),theta_std=float(theta[inds].std()),net_current_A=float(j[faces].sum()*A)))
        edgepower=self.eg*(self.Vt*(phi[self.ea]-phi[self.eb]))**2
        ionic_edge=self.ea>=self.nc
        e_drop=self.Vt*(phi[self.ca]-phi[-1])+j*self.h/(2*p['sigma']);i_drop=-self.Vt*phi[self.se]+j*self.h/(2*p['kappa'])
        return dict(time_s=t,charge_C=self.I*t,theta_mean=float(theta.mean()),theta_std=float(theta.std()),theta_min=float(theta.min()),theta_max=float(theta.max()),surface_min=float(ts.min()),surface_max=float(ts.max()),terminal_relative_U0_V=float(phi[-1]*self.Vt),current_cam_A=float(Icam),current_ise_A=float(Iion),current_BV_A=net,current_relative_error=float(max(abs(Icam-self.I),abs(Iion-self.I),abs(net-self.I))/self.I),inventory_error_C=charge-self.I*t,inventory_relative_error=float(abs(charge-self.I*t)/max(self.I*t,self.I)),face_exchange_opposition_error_A=float(np.max(abs(np.asarray(self.B.sum(axis=0)).ravel()*j*A))),j_std=float(j.std()),j_mean=float(j.mean()),j_cv=float(j.std()/abs(j.mean())),j_rms=float(np.sqrt(np.mean(j*j))),eligible_j_cv=float(eligible_j.std()/abs(eligible_j.mean())),ionic_ohmic_power_W=float(edgepower[ionic_edge].sum()+self.Vt**2*np.dot(self.ground,phi**2)),electronic_ohmic_power_W=float(edgepower[~ionic_edge].sum()),eligible_mean_ionic_drop_V=float(i_drop[self.eligible].mean()),eligible_mean_electronic_drop_V=float(e_drop[self.eligible].mean()),gauge_current_A=float(np.max(abs(self.gauge_g*self.Vt*phi))),regions=regions)

    def run(self,dt=2.,duration=None,name=None,scheme='BE'):
        start=time.perf_counter();duration=duration or self.par['duration'];steps=int(round(duration/dt));assert abs(steps*dt-duration)<1e-10
        self.time_weight=.5 if scheme=='CN' else 1.
        self.theta_fixed=np.full(self.nc,self.par['theta0']);phi=np.zeros(self.np)
        initial_guess=os.environ.get('BM03_INITIAL_GUESS')
        if initial_guess:
            f=np.load(initial_guess);coarse_shape=f['shape'];ratio=self.labels.shape[0]/int(coarse_shape[0]);mapping=np.full(tuple(coarse_shape),-1,int);mapping[tuple(f['coords'].T)]=np.arange(len(f['coords']));ids=mapping[tuple(np.floor((self.coords+.5)/ratio).astype(int).T)];assert np.all(ids>=0)
            initial=f['states'][0];phi[:-1]=initial[ids];phi[-1]=initial[len(f['coords'])]
            print('INITIAL_GUESS',initial_guess,'algebraic potentials only; theta remains prescribed',flush=True)
        phi,init_factor,h0=self.newton(phi);del init_factor;x=np.r_[phi,self.theta_fixed];records=[self.metrics(x,0.)];hist=[h0];states=[x.copy()];factor=None
        for k in range(1,steps+1):
            old=x[self.np:].copy();oldj=self.reaction(x[:self.np],old)[0];self.explicit_rate=self.par['D']/self.h**2*(self.Kdiff@(old-self.par['theta0']))-(self.C@oldj)/(self.par['F']*self.par['cmax']*self.h)
            x,factor,h=self.newton(x,old,dt,factor);hist.append(h);records.append(self.metrics(x,k*dt))
            if k in [steps//2,steps]:states.append(x.copy())
            if k==1 or k==steps or k%5==0:print('STEP',name,k,'/',steps,'V',records[-1]['terminal_relative_U0_V'],'std',records[-1]['theta_std'],'res',h[-1],'sec',time.perf_counter()-start,flush=True)
        if name:
            j,_,_,ts=self.reaction(x[:self.np],x[self.np:]);np.savez_compressed(EC/f'{name}_fields.npz',coords=self.coords,cam_coords=self.cam,interface_centers=self.cent,face_axis=self.axes,parent_face=self.parent,cam_face=self.ca,ise_face=self.se,loss=self.loss,eligible=self.eligible,region=self.region,x=x,j=j,theta_surface=ts,states=np.array(states),shape=self.labels.shape)
            result=dict(name=name,case=self.case,refine=self.r,h_m=self.h,dt_s=dt,duration_s=duration,parameters=self.par,unknowns=self.np+self.nc,phase_voxels=np.bincount(self.labels.ravel(),minlength=3).tolist(),cam_mass_kg=self.mass,volume_cam_m3=self.Vcam,interface_area_m2=self.nf*self.h**2,lost_area_m2=float(self.loss.sum()*self.h**2),Iapp_A=self.I,seconds=time.perf_counter()-start,newton_history=hist,records=records,scope='3D conservative finite-volume electrochemical reference; controlled missing inputs, not measured full-cell prediction',parameter_source='parameters.json in this results directory')
            result['time_scheme']=scheme;result['linear_solver']=os.environ.get('BM03_LINEAR_SOLVER','pardiso');result['linear_threads']=int(os.environ.get('BM03_THREADS','18')) if result['linear_solver']=='pardiso' else 1
            result['initial_algebraic_guess']=str(initial_guess) if initial_guess else 'zero'
            result['newton_merit']='max(local residual / 2e-8, integrated current error / 1e-8)'
            (EC/f'{name}.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print('COMPLETE',name,result['seconds'],flush=True)
        return x,records

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--case',default='baseline',choices=['baseline','concentrated','dispersed']);parser.add_argument('--refine',type=int,default=1);parser.add_argument('--dt',type=float,default=2.);parser.add_argument('--duration',type=float,default=20.);parser.add_argument('--name');parser.add_argument('--parameters',default='{}');parser.add_argument('--scheme',default='BE',choices=['BE','CN']);args=parser.parse_args()
    model=Model(args.case,args.refine,json.loads(args.parameters));print('MODEL',model.np+model.nc,'faces',model.nf,'gauges',model.gauge,flush=True)
    model.run(args.dt,args.duration,args.name or f'{args.case}_r{args.refine}_dt{args.dt:g}',args.scheme)
