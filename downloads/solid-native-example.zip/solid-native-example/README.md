# Minimal executable R2 reproduction

This example solves the original native R2 A/B pair with the unchanged conservative nonlinear electrochemical engine. It is a reproduction of existing results, not a new study or experimental validation.

## Inputs and attribution

`input/geometry.npz` contains the original 32 × 32 × 32 three-phase labels, face coordinates, component labels, eligibility flags, and exact intact/A/B masks. Analysis-array origin is zero-based `(z,y,x)=(35,408,239)` in BM03, with 100 nm voxels. The public dataset is FIB–SEM tomography, DOI https://doi.org/10.22029/jlupub-18458, by Philip Minnmann and Johannes Schubert. Its license is CC BY-NC 4.0: https://creativecommons.org/licenses/by-nc/4.0/ . The geometry extract and geometry-derived assets retain this attribution and license. No additional license to the original data is implied.

The full dataset is not needed to run this packaged extract. To independently retrieve its source, follow the DOI repository record, download the BM03 segmented images, arrange the segmentation in analysis order `(413,713,850)`, and extract `[35:67,408:440,239:271]`. Phase labels are 0 pore, 1 CAM, 2 ISE. Exact loss locations are supplied rather than regenerated from descriptive labels. The provenance file contains hashes and original project-relative reference paths.

## Run

Tested with Python 3.12.14, NumPy 2.3.5 and SciPy 1.16.3 on Windows. From this directory:

```text
python -m pip install -r requirements.txt
python run_example.py
```

The first command requires package access only if the dependencies are absent. The calculation itself uses no network, COMSOL, PARDISO or project paths. It requests one BLAS thread and uses SciPy SuperLU. Outputs are written to `results/`; to retain a completed run and repeat the check, choose `python run_example.py --output another_results`.

The example performs initial galvanostatic potential solves followed by 40 Crank–Nicolson steps of 0.5 s for each mask, at 5.45482 pA and 20 s. It writes A/B endpoint fields, time records and a validation receipt. It retains all phase potentials and CAM concentrations. A and B each remove 650 interface faces (6.50 µm²). Inactive faces have zero reaction current and phase volumes remain unchanged.

## Expected outputs and acceptance

- `W_A = 1.4888162396866534e-5` and `W_B = 1.4743705472588387e-5` on all 5803 original CAM cells.
- `delta_W = +1.4445692427814537e-7`.
- Maximum endpoint concentration difference from packaged expected fields < 1e-7.
- Relative interface-current L2 difference < 1e-5; terminal-potential difference < 1e-6 V.
- Relative variance difference < 1e-5 and absolute paired-contrast difference < 1e-10.
- Relative current and inventory imbalance < 1e-6; sampled cell/surface concentration stays within 0.05 of 0.65.

The script checks hashes before solving and raises an error if a numerical requirement fails. The included `validation.json` records the actual successful run used for this revision (about 21 seconds on the author's machine; this is not a runtime guarantee or speed comparison). This native-grid example does not reproduce all refinement levels, all frozen patterns, or the entire simulation archive.

`bm03_ec_model.py` is copied byte-for-byte from the original project. The `interfaces` and `geometry_metrics` functions in `bm03_ec_geometry.py` are copied without equation changes; its imports and input path are made portable. `source_provenance.json` identifies these adaptations.
