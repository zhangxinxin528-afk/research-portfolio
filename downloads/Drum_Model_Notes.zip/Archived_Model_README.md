# 文献结构鼓式浸出反应器：CAD、三维流场与浸出/PBM

本项目从文献中的穿孔鼓结构重建真实三维 B-rep CAD，再提取鼓内、穿孔、鼓外槽连通的满液域，计算 COMSOL 三维流场。化学阶段使用流场积分得到的体积、交换流量及局部剪切率，驱动五分区浸出/粒数衡算。它是 **CFD–分区模型的一向耦合**，化学阶段每区完全混合，不是三维浓度有限元求解。

## 先看几何

- `figures/01_full_CAD_assembly.png`：完整装配，外槽透明。
- `figures/02_CAD_cutaway.png`：实体布尔剖切，显示鼓壳和内部轴系。
- `figures/03_dimensioned_sections.png`：同一 CAD 的纵、横剖面和主要尺寸。
- `cad/full_assembly_scaled_half.step`：实际计算尺度完整 CAD，45 个封闭实体。
- `cad/full_assembly_reference_scale.step`：参考尺度完整 CAD，与缩小版之间是严格均匀相似变换。
- `cad/longitudinal_cutaway.step`：移去前半侧的实体剖切。
- `cad/longitudinal_section.step`、`transverse_section.step`：中心 ±1 mm 薄片实体剖面。
- `models/01_literature_CAD_assembly.mph`：COMSOL 原生导入的完整机械装配。

CAD 为圆柱实体、穿孔布尔运算和装配实体，并非渲染模型或半圆柱流体外表面。机械实体含穿孔鼓、法兰、可拆端盖、16 个螺栓、轮毂、整根轴、两侧密封、轴承支座、电机、联轴器、底座、外槽、槽盖及两处封闭接口。实体干涉审查不含接触面，但检查了有体积的重叠。

## 结构来源与假设

Egedy 等 (2014)，*CFD Assisted Scale Up of a Rotating Drum Leaching Reactor*，Chemical Engineering Transactions 39, 901–906，DOI [10.3303/CET1439151](https://doi.org/10.3303/CET1439151)。选 Figure 1(c)、Table 1 Case 12：穿孔旋转鼓位于固定外槽内。论文给出鼓径 0.3 m、周向 8 排、每排轴向 3 孔。

**原文孔径单位存在冲突**：正文为 2–5 cm，图注为 2–5 mm，表头为 m 而数值为 2–5。本模型明确按正文选择 20 mm 参考孔径，不能称作已确认的原文尺寸。鼓长、壁厚、端盖、外槽、轴系、驱动及支架等未提供尺寸均为工程假设。完整来源表见 `geometry_manifest.json`。这是按文献示意重建并补全的工程 CAD，不能称作论文原始制造图的逐尺寸复制。

按用户允许统一缩尺，所有长度乘 0.5，面积乘 0.25，体积乘 0.125。计算鼓径 150 mm、鼓长 200 mm、孔径 10 mm、鼓壁 2 mm，外槽内腔 300×300×300 mm。尺寸缩小本身不会减少相同相对分辨率下的网格数；本模型同时使用孔道局部细化和受控网格过渡。未声称缩尺前后流动、传质或反应相似。

## COMSOL 流场

使用实际 CAD 提取的连通满液域，鼓的 24 个孔真正贯通。端盖紧固件在流场模型中替换为密封平齐外包络，机械 CAD 中仍保留螺栓。计算假定密封批式、满液，无气相和自由液面；两处进出接口以盲盖封闭。

- 转速 10 rpm、浆料密度 1100 kg/m³、牛顿黏度 0.05 Pa·s，均为假设。
- 等温 60 °C；不解能量方程，黏度不随浓度或粒径更新。
- 三维 Laminar Flow + Rotating Domain + Frozen Rotor，鼓内/近鼓区域旋转，固定外槽静止。移动鼓壁使用 Automatic from frame，使孔壁的完整运动速度进入边界条件。
- 使用实验室坐标系速度；在轴对称的转静子界面上，绝对速度和相对速度的法向分量相同。
- 冻结转子是固定角位置的稳态近似，不是随时间滑移网格的逐圈求解。
- 采用二次速度/一次压力离散，PARDISO，转速逐级递增至 10 rpm。

`models/02_flow_coarse_SOLVED.mph` 和 `02_flow_fine_SOLVED.mph` 是粗、细网格的已求解原生模型。`data/flow_*_volume.txt` 和两个中心剖面的 txt 是原生数值导出。积分审查见 `data/flow_coupling_audit.json`，它比较平均/RMS 速度、平均剪切与分区总交换流量；两档比较只验证这些积分量，不代表所有局部量已经网格无关。

最终两档为 94,407 与 112,577 个四面体，前一档 78,009 单元保留为 initial 模型。鼓内接近刚体旋转的弱剪切区，其平均剪切率仍有较大的相对网格差异，具体数值列在审查 JSON；因此另检查这些 CFD 输入变化对浸出结果的敏感性，不把局部剪切场称为已网格无关。

## CFD 与化学/PBM 的连接

五分区是本项目构造的流体控制体，没有添加物理隔墙：0 鼓内及孔道；1 近鼓环隙和端部；2 左端外槽；3 右端外槽；4 中央外槽。它们不是照搬论文原始分区的尺寸。

COMSOL 对六组相邻界面的正、反向体积流量分别积分，得到 Q[i,j]（i→j）。有限元速度积分的局部净流量可能有残差；以保留每个界面总交换量的加权投影做守恒平衡，检查修正幅度后得到 Q。原始值、修正值及误差全部保留在 `data/cfd_compartment_coupling.json`、`flow_coupling_audit.json`。分区浓度输运算子为

`A = [Qᵀ − diag(Q 的行和)] / V_i`，`dc_i/dt = (A c)_i + source_i`。

A 应保持均匀示踪剂且守恒体积加权总量，均有数值审查。所有粒径群、已溶金属、酸当量与装料示踪剂均使用同一算子。源文件保留流场模型 SHA256，以追踪实际输入。

## 浸出与粒数衡算

结构论文原系统为 WEEE/Cu/FeCl₃，本项目为响应黑粉关键金属回收目标，另用 Segura-Bailon 等 (2025)，*Li-Ion Battery Recycling via High-Intensity Milling Followed by Organic Acid Leaching for Preferential Lithium Extraction*，Batteries，DOI [10.3390/batteries11120458](https://doi.org/10.3390/batteries11120458)。1 M 柠檬酸、60 °C、50 g/L 黑粉；Figure 5(a) 近似手工数字化用于表观动力学拟合，Figure 5(b) 为不同酸浓度的条件检查。它是盘磨预处理后搅拌浸出实验，不是该鼓式设备的实验验证。Cu 和 Al 的条件外推误差较大，原始拟合误差见 `data/fitted_parameters.json`。

`data/kinetics_provenance.json` 保存动力学来源、实验物料条件和反应域假设。当前装置的几何由 `geometry_manifest.json` 单独定义，方程由 `reaction.py` 生成；动力学文献的实验容器尺寸不用于本装置 CAD。

61 个离散尺寸节点覆盖 1–500 μm，6 种金属 Li/Ni/Mn/Co/Al/Cu 各自拥有独立的虚拟反应域 PBM。q 表示以各金属初始库存归一的粒数；体积权重 w=(d/100 μm)³。初始体积/质量分布为对数正态，中位径 100 μm，几何标准差 1.5，均为假设。

- 溶解收缩：`vel_e,j = k_e /(1+t/60s)^p_e × min(max(E_j/100mol·m⁻³,0),1)`。这是条件化的表观反应域退缩率，不能预测未标定的机械化学晶格活化。
- 尺寸空间采用体积上风通量；溶解损失进入同金属的液相库存，精确保留离散金属账目。
- 二元等体积破碎，子粒子按相邻体积节点线性分配；不能表示的最小子粒子破碎被关闭。
- 假设破碎率 `10⁻⁴ s⁻¹ × (d/100μm) × [0.2+0.8 γ_j/γ̄]`，γ_j 来自 CFD。无碰撞/研磨介质 DEM 数据，破碎核未做实验标定。
- 该破碎核用于演示数值耦合，不能仅凭液体剪切率断言黑粉实际发生相同程度的破碎。颗粒群随液体作分区交换，忽略沉降、颗粒惯性和筛孔选择性。
- 六套金属反应域不是共享的真实多组分黑粉颗粒。图中的 Li 粒径分布与 d32 必须称作虚拟反应域尺寸，不能当作黑粉整体激光粒度结果。
- 鼓内初始装料为全槽平均的 2 倍，其余各区调低以保持全槽 50 g/L；这是为观察有限交换作用设定的非均匀初值。
- 酸库存初值 3000 mol-equivalent/m³；化学计量系数 Li/Ni/Mn/Co/Al/Cu 为 1/2/2/2/3/2。酸当量账目不等于自由 H⁺、pH 或完整柠檬酸络合/氧化还原平衡。

1870 个常微分状态：1830 个粒数群 + 30 个液相金属 + 5 个酸库存 + 5 个装料示踪剂。时间 0–7200 s，每 60 s 输出。`models/03_CFD_compartment_leaching_PBM.mph` 中包含完整机械 CAD 和原生 COMSOL Global Equations。3D CFD 解保存在单独的 02 模型，通过 V/Q/γ 数据单向耦合；溶解后的密度、黏度、固相负载不反馈流场。

## 结果与复现

`figures/04_flow_fine_native.png` 为 COMSOL 原生三维切片；`05_flow_sections.png`、`06_CAD_and_3D_flow.png` 显示实际 CAD 与流场的对应关系。`07_leaching_vs_time.png` 是全槽浸出率，`08_PSD_vs_time.png` 是 Li 虚拟域的粒径随时间变化，`09_regional_leaching_and_size.png` 显示区域浓度和尺寸矩。

全量数据在 `data/coupled_comsol_states.csv`、`coupled_results.npz`；便读结果在 `leaching_history.csv`、`Li_virtual_domain_PSD_history.csv`。`data/reaction_audit.json` 记录独立 SciPy BDF 对照、金属/酸守恒、破碎单独作用时不释放金属的控制试验，以及 61→121 尺寸节点、粗细 CFD 网格对最终浸出结果的敏感性。`figures/10_kinetics_calibration.png` 单独展示表观动力学的文献曲线拟合与不同酸浓度条件的误差。

需要 COMSOL 6.4（CFD、CAD Import；本机可用），Python 及 NumPy/SciPy/Matplotlib/Gmsh。`run_comsol.py` 会在项目目录建立独立运行目录并记录源代码哈希和执行日志，COMSOL 根目录目前在 D:/COMSOL/COMSOL64/Multiphysics。

1. `build_cad.py`、`audit_interference.py`、`audit_scale.py`、`render_cad.py`：建立和检查 CAD。
2. `extract_fluid_cad.py`：从 CAD 提取流体及控制体。
3. `python run_comsol.py LiteratureDrumFlow.java`：粗、细 CFD。
4. `python refine_flow.py` → `python run_comsol.py RefineFlow.java`：用已收敛解作初值进一步细化孔道与全局网格，保留上一级为 coarse；随后 `python run_comsol.py ExportNativeFlowPlot.java` 增加原生流线图。重新执行流场审查会更新最终模型哈希。
5. `python process_flow.py`：审查后生成守恒分区交换算子；审查不通过则拒绝生成后续方程。
6. `python reaction.py build` → `python run_comsol.py LiteratureDrumReaction.java` → `python reaction.py`：生成原生方程、求解、独立核对。
7. `python render_results.py`：用原生结果绘图。
8. `python add_reaction_plots.py` → `python run_comsol.py AddReactionPlots.java`：在已求解 COMSOL 模型中加入粒径矩、金属/酸账目和酸库存曲线。
9. `python run_comsol.py ExportNativeResults.java`：设置元素图例和分钟时间轴，保存并直接导出 COMSOL 原生结果图。`figures/12_native_COMSOL_leaching.png` 至 `15_native_COMSOL_balance.png` 分别为浸出率、d32、酸当量和守恒误差。
10. `python prepare_cad_overlay.py` → `python run_comsol.py ExportAssemblyFlowOverlay.java`：把原装配的 45 个实体按机械类别导出到 `cad/display_groups/`，作为独立显示组件加入已求解流场；保存 `models/04_full_CAD_flow_overlay.mph`。在结果节点 `pgAssemblyFlow` 中，外槽/槽盖透明度为 94%，鼓壳/法兰/轮毂为 88%，端盖为 78%，支架、电机和轴保持可见。CAD 网格数据集的毫米坐标通过绘图变换乘 0.001，与米制 CFD 数据对齐；不改变 CFD 几何、网格或解。`figures/16_native_full_CAD_flow_overlay.png` 是原生 COMSOL 同场叠加导出，并非两张图片拼接。
11. `python render_full_psd.py`：直接读取原生解归约数据，输出 `17_Li_full_PSD_time.png`（五个时刻的 Li 体积分布密度及粒径–时间热图）和 `18_six_metals_full_PSD.png`（六元素完整分布）；纵轴为 `dQ/dln(d)`，各时刻按剩余固相体积归一至 100%。`data/full_PSD_all_metals_long.csv` 同时保存分箱体积分数、分布密度和相对初始库存的绝对剩余体积。61 个离散节点的细节原样保留，不作美化平滑；尺寸群收敛目前仅检查浸出率和 d32，尚未验证完整 PSD 的分布误差。图是 Python 对 COMSOL PBM 数值解的科学绘图，分布含义仍为虚拟反应域，不代表真实共享黑粉颗粒。

所有验证均为明确假设下的数值核对。本模型可用于后续研究框架与敏感性分析，尚未通过实际鼓式黑粉浸出和破碎实验标定。

<!-- VERIFIED_NUMBERS_START -->

## 本次实际计算结果

细网格 112,577 个四面体；平均速度 0.02199 m/s，平均剪切率 0.8736 s⁻¹。区域交换流量守恒平衡的相对 L2 修正为 0.726%。

| 金属 | 120 min 全槽浸出率 / % |
|---|---:|
| Li | 74.28 |
| Ni | 62.37 |
| Mn | 58.17 |
| Co | 56.34 |
| Al | 97.09 |
| Cu | 84.61 |

最大金属库存误差 5.11e-15；最大酸当量账目误差 4.55e-15。独立求解器的浸出率最大差异 1.07e-05 个百分点；61→121 尺寸节点的最大差异 0.492 个百分点；CFD 粗细网格对浸出率的最大差异 0.000 个百分点。

这些数值仅对应上述假设、缩尺尺寸和动力学，不能作为原论文装置或真实黑粉鼓式反应器的实验回收率。
<!-- VERIFIED_NUMBERS_END -->
